let svg
let svgArea
let mouseStartX = 0
let mouseStartY = 0
let moveG = null
let moveP = null
let movePath = false
let movePoint = false
let pointIndex = 0
window.onload = () => {
    svgArea = document.getElementById('mysvg')
    svg = {
        points: [[100, 100], [150, 350], [350, 350], [500, 100]],
        text: 'I love SVG',
    }
    let g = document.createElementNS('http://www.w3.org/2000/svg', 'g')
    g.setAttribute('id', 'myg')
    // 画路径
    let path = document.createElementNS('http://www.w3.org/2000/svg', 'path')
    let d = 'M'
    svg.points.map((item , index) => {
        if (index == 0) {
            d += `${item[0]} ${item[1]} `
        } else {
            d += `L${item[0]} ${item[1]} `
        }
    })
    d += 'Z'
    path.setAttribute('d', d)
    path.setAttribute('fill', 'lightblue')
    path.setAttribute('stroke', 'black')
    path.addEventListener('mousedown', () => {startMove()}, false)
    path.addEventListener('mouseup', () => {stopMove()}, false)
    g.appendChild(path)
    // 画顶点
    svg.points.map((item, index) => {
        let c = document.createElementNS('http://www.w3.org/2000/svg', 'circle')
        c.setAttribute('cx', item[0])
        c.setAttribute('cy', item[1])
        c.setAttribute('fill', 'red')
        c.setAttribute('r', 5)
        c.addEventListener('mousedown', () => {startMovePoint(event, index)}, false)
        c.addEventListener('mouseup', () => {stopMovePoint()}, false)
        g.appendChild(c)
    })
    // 画文本
    let text = document.createElementNS('http://www.w3.org/2000/svg', 'text')
    text.setAttribute('text-anchor', 'middle')
    text.setAttribute('fill', 'black')
    // 计算文本的位置
    text.setAttribute('x', 100)
    text.setAttribute('y', 100)
    text.innerHTML = 'I LOVE SVG'
    g.appendChild(text)
    svgArea.appendChild(g)
}

startMove = () => {
    let ev = window.event
    mouseStartX = ev.x
    mouseStartY = ev.y
    moveG = document.getElementById('myg')
    movePath = true
}



stopMove = () => {
    movePath = false
    mouseStartX = 0
    mouseStartY = 0
    moveG = null
}

mouseMove = (event) => {
    let moveX = event.x - mouseStartX
    let moveY = event.y - mouseStartY
    if (movePath) {
        let d = 'M'
        svg.points.map((item, index) => {
            item[0] = item[0] + moveX
            item[1] = item[1] + moveY
            if (index == 0) {
                d += `${item[0]} ${item[1]} `
            } else {
                d += `L${item[0]} ${item[1]} `
            }
        })
        d += 'Z'
        for (let item of moveG.children) {
            if (item.tagName === 'path') {
                item.setAttribute('d', d)
            } else if (item.tagName === 'circle') {
                item.setAttribute('cx', parseInt(item.attributes['cx'].nodeValue) + moveX)
                item.setAttribute('cy', parseInt(item.attributes['cy'].nodeValue) + moveY)
            }
        }
    }
    if (movePoint) {
        moveP.setAttribute('cx', parseInt(moveP.attributes['cx'].nodeValue) + moveX)
        moveP.setAttribute('cy', parseInt(moveP.attributes['cy'].nodeValue) + moveY)
        svg.points[pointIndex] = [parseInt(moveP.attributes['cx'].nodeValue), parseInt(moveP.attributes['cy'].nodeValue)]
        let d = 'M'
        svg.points.map((item, index) => {
            if (index == 0) {
                d += `${item[0]} ${item[1]} `
            } else {
                d += `L${item[0]} ${item[1]} `
            }
        })
        d += 'Z'
        moveG.children[0].setAttribute('d', d)
    }
    mouseStartX = mouseStartX + moveX
    mouseStartY = mouseStartY + moveY
}

startMovePoint = (ev, index) => {
    movePoint = true
    mouseStartX = ev.x
    mouseStartY = ev.y
    moveG = document.getElementById('myg')
    moveP = moveG.children[index + 1]
    pointIndex = index
}

stopMovePoint = () => {
    movePoint = false
    mouseStartX = 0
    mouseStartY = 0
    moveG = null
    moveP = null
    pointIndex = 0
}